#ifndef _ATCCONFIG_H
#define _ATCCONFIG_H

#define			_ATC_DEBUG                                    1   // 0: disable      1:debug        2: Print all rx data
#define			_ATC_MAX_DEVICE                               1
#define			_ATC_MAX_SEARCH_PARAMETER_FOR_AT_ANSWER       10
#define			_ATC_MAX_AUTO_SEARCH_STRING                   20

#endif
