
#include "ATC.h"


void		ATC_User_AutoSearchCallBack(uint8_t  ID,uint16_t	FoundIndex,char *FoundString,char *ATC_rxDataPointer)
{
 
}

